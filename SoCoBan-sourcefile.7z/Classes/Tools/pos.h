#pragma once
class pos
{
public:
	long x;
	long y;
};

