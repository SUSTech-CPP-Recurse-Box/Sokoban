#include "controler.h"
controler* controler::_instance = new controler();